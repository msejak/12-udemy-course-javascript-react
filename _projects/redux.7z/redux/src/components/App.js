import Counter from './Counter';

function App() {
  return <Counter />;
}

export default App;
